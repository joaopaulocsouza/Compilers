#ifndef INLCUDES_HPP
#define INLCUDES_HPP

#include <iostream>
#include <string>
#include <vector>
#include "functions.hpp"
#include <vector>
#include <queue>
#include <stack>
#include <string>
#include "defines.hpp"

extern int finalStates[176];
extern int edges[176][256];

#endif