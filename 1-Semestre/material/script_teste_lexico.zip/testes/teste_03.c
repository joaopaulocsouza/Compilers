foo (a)
{
  return a & 65535;
}
