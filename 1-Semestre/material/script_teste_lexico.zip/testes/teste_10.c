foo (a)
{
  int b = a + 1;
  int c = (short) a;
  if (b)
    return b;
  return 1;
}

void* algoritmo(char* "oi")
{
    int i = "SkyNet online" + 666 @ "you are terminated";
    
    switch(default)
    {
        case 77: "do something"; break;
        case 666: segmentation_fault++; break;
        default: ++error_level++;
    }
    for(;;){;;;}
    
    i ? (3>4)7:8;
    a->t = i[+666*"blabla"][45];
    
    while(i=j>=6<=7){;;;}
    
}

int funcao(int a, char b)
{
    int i;
    char c;
    
    07 + 08 + 007 + 008 + 0x9 + 0X9;
    
    c = *funcao + "oi mundo"; 
    
    
    return (0xa /* -00 */ + 0XA /* + 48 */ + 007 + 07);
}
/*

/* comentario // comentario

// comentario 

     /*  /*  /*
     /*
     
     

if(a>b)
{
    identificador = a > b;
    i = 666;
}

   /* comentario
//
  //*/

void blabla()
{
    
int 
Nome_De_Variavel_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx,
Nome_De_Variavel_2_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx,
Nome_De_Variavel_3_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx,
Nome_De_Variavel_4_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;


/*/
// Compilar ou nao compilador, eis a questao...
// 
// Dar erro ou warning, oh duvida cruel...
//
// Segmentation fault
//
/*/

if(1)
{
    ff = (int) 23/ *i;
    ch = '\a';
    ch = '\b';
    ch = '\f';
    ch = '\n';
    ch = '\r';
    ch = '\t';
    ch = '\v';
    ch = '\\';
    ch = '\'';
    ch = '\"';    
    ch = '\?';
    ch = '\0';

    ch = '!';
    ch = '@';
    ch = '#';
    ch = '$';
    ch = '%';
    ch = '^';
    ch = '&';
    ch = '*';
    ch = '(';
    ch = ')';
    ch = '_';
    ch = '?';
    ch = ' ';
    ch = '+';
    ch = '-';
    ch = '/';
    ch = '.';
    ch = ':';
    ch = ';';
    ch = '<';
    ch = '=';
    ch = '>';
    ch = ',';
    ch = '[';
    ch = ']';
    ch = '}';
    ch = '{';
    ch = '`';
    ch = '~';
    ch = '|';
/* oi */  /* isto eh um
   comentario iniciado
   e nao terminado
