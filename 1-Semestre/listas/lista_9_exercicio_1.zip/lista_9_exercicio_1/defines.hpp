#ifndef DEFINES_HPP
#define DEFINES_HPP

#include "includes.hpp"

#endif