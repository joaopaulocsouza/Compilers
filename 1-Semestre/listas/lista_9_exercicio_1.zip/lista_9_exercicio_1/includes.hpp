#ifndef INLCUDES_HPP
#define INLCUDES_HPP

#include <iostream>
#include <string>
#include <vector>
#include "functions.hpp"
#include <vector>
#include <string>
#include "defines.hpp"

extern int finalStates[29];
extern int edges[29][29];
extern std::string str;
// int token;

#endif